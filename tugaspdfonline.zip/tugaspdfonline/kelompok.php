<div class="container pt">
		<div class="row mt">
			<div class="col-lg-6 col-lg-offset-3 centered">
				<h3>KELOMPOK</h3>
				<hr>
			<table class='table table-stripped'>
				<tr>
					<td>Nama</td>
					<td>:</td>
					<td>Arif Kurniawan (14.01.53.0128)</td>
				</tr>
				<tr>
					<td>Nama</td>
					<td>:</td>
					<td>Rachmad Bayu Sejati (14.01.53.0133)</td>
				</tr>
				<tr>
					<td>Nama</td>
					<td>:</td>
					<td>Ahmad Fuad (14.01.53.0118)</td>
				</tr>
			</table>
			</div>
		</div>
	</div>